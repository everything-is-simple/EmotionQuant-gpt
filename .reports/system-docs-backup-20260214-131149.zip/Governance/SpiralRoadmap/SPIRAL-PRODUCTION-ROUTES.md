# EmotionQuant 实战螺旋路线手册（S0-S7a）

**状态**: Active  
**更新时间**: 2026-02-13  
**用途**: 给出可直接执行的多路线方案，避免“提案遗忘”。

---

## 1. 适用原则

1. 所有路线必须遵守 `Governance/steering/系统铁律.md` 与 `Governance/steering/6A-WORKFLOW.md`。
2. 每圈必须有 `run/test/artifact/review/sync` 五件套。
3. 一旦启用 ENH-10/ENH-11，必须作为独立圈收口，不允许“顺手做了不留证据”。

---

## 2. 三套可执行路线

### 路线 A（推荐，平衡实战）

> 目标：先完成信号可用，再补数据效率，再推进回测/交易/展示，最后补自动运维。

| 顺序 | Spiral | 主目标 | 预算 |
|---|---|---|---:|
| 1 | S0a/S0b/S0c | 入口+L1+L2 数据闭环 | 8d |
| 2 | S1a/S1b | MSS 评分与消费验证 | 5d |
| 3 | S2a/S2b/(S2r) | MSS+IRS+PAS+Validation 集成推荐 | 7-9d |
| 4 | S3a | ENH-10 分批+断点续传+多线程 | 2.5d |
| 5 | S3 | 回测闭环（Qlib+本地口径） | 4d |
| 6 | S4 | 纸上交易闭环 | 4d |
| 7 | S5 | GUI 与日报导出闭环 | 3d |
| 8 | S6 | 稳定化与一致性重跑 | 3d |
| 9 | S7a | ENH-11 自动调度与开机自启 | 1.5d |

适用场景：你要尽快进入“可跑、可测、可复盘、可日更”的实战节奏。

### 路线 B（稳健，风险优先）

> 目标：先把质量门和交易一致性打牢，再上自动化能力。

| 顺序 | Spiral | 主目标 | 预算 |
|---|---|---|---:|
| 1 | S0a/S0b/S0c | 数据基础闭环 | 8d |
| 2 | S1a/S1b | MSS 闭环 | 5d |
| 3 | S2a/S2b/S2r | 信号集成+故障修复演练 | 8-10d |
| 4 | S3 | 回测闭环 | 4d |
| 5 | S4 | 纸上交易闭环 | 4d |
| 6 | S6 | 稳定化提前执行（先稳后展） | 3d |
| 7 | S3a | ENH-10 数据效率增强 | 2.5d |
| 8 | S5 | 展示闭环 | 3d |
| 9 | S7a | ENH-11 自动调度 | 1.5d |

适用场景：你更看重“误触发风险最小化”，接受稍慢上线。

### 路线 C（激进，速度优先）

> 目标：最快拿到可运转主链，接受后续返工概率上升。

| 顺序 | Spiral | 主目标 | 预算 |
|---|---|---|---:|
| 1 | S0a+S0b | 入口+L1 同圈完成 | 5d |
| 2 | S0c+S1a | L2+MSS 同圈完成 | 4d |
| 3 | S1b+S2a | MSS 消费验证 + IRS/PAS/Validation | 5d |
| 4 | S2b/(S2r) | 集成推荐收口 | 3-4d |
| 5 | S3a | ENH-10 | 2.5d |
| 6 | S3+S4 | 回测与纸上交易并行推进 | 6d |
| 7 | S5+S6 | 展示与稳定化 | 5d |
| 8 | S7a | ENH-11 | 1.5d |

适用场景：你明确要快速迭代并愿意承担并圈复杂度。

---

## 3. 每圈统一门禁（实战必过）

1. `run`：命令可重复执行且参数可追溯。
2. `test`：至少 1 条自动化测试；涉及数据契约/交易路径必须加契约测试。
3. `artifact`：至少 1 个结构化产物 + 1 份结论报告。
4. `review`：偏差、风险、降级方案写入 `review.md`。
5. `sync`：完成 5 文件最小同步。
6. `A股规则`：涉及推荐/交易必须检查 T+1、涨跌停、交易时段、申万行业映射。

---

## 4. ENH-10 / ENH-11 固化执行合同

### S3a（ENH-10）必交付

- 命令：
  - `eq fetch-batch --start {start} --end {end} --batch-size 365 --workers 3`
  - `eq fetch-status`
  - `eq fetch-retry`
- 门禁：
  - 支持断点续传（中断后可继续）。
  - 多线程吞吐显著优于单线程（报告给出实测值）。
  - 失败批次有重试记录。
- 产物：
  - `fetch_progress.json`
  - `throughput_benchmark.md`
  - `fetch_retry_report.md`

### S7a（ENH-11）必交付

- 命令：
  - `eq scheduler install`
  - `eq scheduler status`
  - `eq scheduler run-once`
- 门禁：
  - 16:00 调度触发可验证。
  - 非交易日自动跳过。
  - 当日重复下载被去重阻断。
- 产物：
  - `scheduler_status.json`
  - `scheduler_run_history.md`
  - `scheduler_bootstrap_checklist.md`

---

## 5. 防遗忘机制（强制）

1. 任何启用的路线圈，必须在 `Governance/record/development-status.md` 写状态（planned/in_progress/blocked/completed）。
2. ENH-10/11 未完成时，不得在状态记录中标记“自动化数据链路完成”。
3. 若连续 2 圈未推进 ENH-10/11，必须在 `Governance/record/debts.md` 新增债务条目与延期原因。

---

## 6. 默认执行建议

- 默认采用 **路线 A（推荐）**。
- 只有在你明确要求“风险优先”或“速度优先”时，才切换到路线 B/C。
- 路线切换时必须在 `Governance/specs/spiral-s{N}/final.md` 记录切换原因与影响范围。

---

## 7. 变更记录

| 版本 | 日期 | 变更 |
|---|---|---|
| v1.0 | 2026-02-13 | 首次发布：给出三套完整实战路线，固化 ENH-10/11，加入防遗忘机制 |
